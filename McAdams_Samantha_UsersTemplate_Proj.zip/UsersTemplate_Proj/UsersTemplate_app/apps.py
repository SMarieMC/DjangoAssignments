from django.apps import AppConfig


class UserstemplateAppConfig(AppConfig):
    name = 'UsersTemplate_app'
