from django.apps import AppConfig


class AuthortemplateAppConfig(AppConfig):
    name = 'AuthorTemplate_app'
