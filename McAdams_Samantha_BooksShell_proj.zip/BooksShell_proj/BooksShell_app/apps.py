from django.apps import AppConfig


class BooksshellAppConfig(AppConfig):
    name = 'BooksShell_app'
