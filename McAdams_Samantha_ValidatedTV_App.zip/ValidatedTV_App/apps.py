from django.apps import AppConfig


class ValidatedtvAppConfig(AppConfig):
    name = 'ValidatedTV_App'
