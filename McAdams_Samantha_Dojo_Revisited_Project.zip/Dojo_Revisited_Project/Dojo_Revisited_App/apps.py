from django.apps import AppConfig


class DojoRevisitedAppConfig(AppConfig):
    name = 'Dojo_Revisited_App'
