from django.apps import AppConfig


class LoginregappConfig(AppConfig):
    name = 'LoginRegApp'
