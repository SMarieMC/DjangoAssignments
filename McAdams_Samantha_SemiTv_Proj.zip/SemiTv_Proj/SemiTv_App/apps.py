from django.apps import AppConfig


class SemitvAppConfig(AppConfig):
    name = 'SemiTv_App'
