from django.apps import AppConfig


class RannumgenAppConfig(AppConfig):
    name = 'RanNumGen_App'
