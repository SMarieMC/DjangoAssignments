from django.apps import AppConfig


class OrmsqlAppConfig(AppConfig):
    name = 'ORMSQL_App'
